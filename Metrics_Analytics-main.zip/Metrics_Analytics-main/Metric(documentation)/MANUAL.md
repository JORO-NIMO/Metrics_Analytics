# Installation and Usage Manual
## Maternal Health Uganda — Lectures 05 & 06 Implementation
### SENG 421 Software Quality Assurance

---

## What Was Added

This release adds full implementation of Lecture 05 (Software Size) and Lecture 06 (Structural Complexity) on top of the existing Lectures 02, 03, and 04 implementation.

**Lecture 05 adds:**
- LOC measurement for all 15 backend PHP files
- Halstead metrics (volume, difficulty, effort) for key files
- Function Point analysis (UFC = 129 function points)
- Reuse metrics per file

**Lecture 06 adds:**
- Cyclomatic complexity v(G) for all 15 files
- Cohesion per module (system cohesion = 72.88%)
- Coupling between module pairs (global coupling = 1.67)
- Fan-in / Fan-out information flow
- Architecture morphology (nodes, edges, depth, width, impurity)
- Data structure complexity

Both are visible in two new tabs on the admin dashboard.

---

## Step 1 — Download and Extract

Download `MaternalHealthUganda_L05_L06.zip` and extract it. You will get a folder called `Metrics_Analytics-main`. Place this folder inside your XAMPP htdocs:

```
C:\xampp\htdocs\Metrics_Analytics-main\
```

---

## Step 2 — Start XAMPP

Open **XAMPP Control Panel** and start both:
- **Apache**
- **MySQL**

Both status lights must turn green before continuing.

---

## Step 3 — Import the Database

1. Open your browser and go to: `http://localhost/phpmyadmin`
2. Click **New** in the left sidebar
3. Type the database name: `maternal_health_uganda`
4. Click **Create**
5. Click the **Import** tab at the top
6. Click **Choose File** and select:
   ```
   C:\xampp\htdocs\Metrics_Analytics-main\database\maternal_health_uganda.sql
   ```
7. Scroll down and click **Import**

You should see a green success message. The database now contains all tables including the 10 new ones for Lectures 05 and 06.

---

## Step 4 — Open the Application

Open your browser and go to:

```
http://localhost/Metrics_Analytics-main/frontend/index.html
```

You should see the Maternal Health Uganda homepage.

---

## Step 5 — Open the Admin Dashboard

Go to:

```
http://localhost/Metrics_Analytics-main/frontend/metrics_dashboard.html
```

Log in with:

| Field | Value |
|---|---|
| Email | `admin@maternalhealthuganda.org` |
| Password | `Admin@1234` |

---

## Step 6 — View the New Tabs

Once logged in to the dashboard you will see six tabs:

| Tab | Contents |
|---|---|
| 📊 Quality Indicators | GQM metrics from Lecture 03 |
| 🔬 Research & Testing | Empirical investigation from Lecture 04 |
| **📐 Software Size** | **Lecture 05 — LOC, Halstead, Function Points, Reuse** |
| **🔀 Complexity** | **Lecture 06 — Cyclomatic, Cohesion, Coupling, Flow, Architecture, Data Structure** |
| 🎯 Measurement Goals | GQM goal tree |
| 📋 Reference Guide | Comparison tables and variable definitions |

Click **📐 Software Size** to see Lecture 05 data.
Click **🔀 Complexity** to see Lecture 06 data.

---

## New Files Added

### Backend

| File | What it does |
|---|---|
| `backend/getsizemetrics.php` | Returns all Lecture 05 size data as JSON |
| `backend/getcomplexity.php` | Returns all Lecture 06 complexity data as JSON |

### Database Tables

| Table | Lecture | Contains |
|---|---|---|
| `loc_measurements` | 05 | LOC, NCLOC, CLOC, comment density per file |
| `halstead_metrics` | 05 | μ1, μ2, vocabulary, volume, difficulty, effort |
| `function_points` | 05 | All EI, EO, EQ, ILF, EIF components with weights |
| `reuse_metrics` | 05 | Verbatim/modified/new LOC per file |
| `cyclomatic_complexity` | 06 | v(G) and risk level per file |
| `cohesion_metrics` | 06 | CH(C) per module |
| `coupling_metrics` | 06 | c(x,y) per module pair |
| `information_flow` | 06 | Fan-in, fan-out, IFC per module |
| `architecture_metrics` | 06 | System nodes, edges, depth, width, impurity |
| `data_structure_complexity` | 06 | C = C1+C2+C3 per file |

### Documentation

| File | Contents |
|---|---|
| `Metric(documentation)/lecture 05 (SoftwareSize).md` | Full Lecture 05 explanation with our numbers |
| `Metric(documentation)/lecture 06 (StructuralComplexity).md` | Full Lecture 06 explanation with our numbers |
| `Metric(documentation)/MANUAL.md` | This file |

---

## Troubleshooting

**Dashboard tabs show "Loading…" forever**
- Make sure Apache and MySQL are both running in XAMPP
- Make sure the database was imported correctly
- Check that `config.php` has the correct database name: `maternal_health_uganda`

**Import fails in phpMyAdmin**
- Make sure you created the database first before importing
- Make sure you selected the correct SQL file

**Page shows blank or 404**
- Make sure the folder is named exactly `Metrics_Analytics-main` inside htdocs
- Make sure Apache is running

---

## Project Structure

```
Metrics_Analytics-main/
├── backend/
│   ├── config.php
│   ├── metrics_logger.php
│   ├── login.php
│   ├── signup.php
│   ├── logout.php
│   ├── savetracker.php
│   ├── logpageview.php
│   ├── submitreview.php
│   ├── submitfeedback.php
│   ├── submitsurvey.php
│   ├── getmetrics.php
│   ├── getexperiments.php
│   ├── getreviews.php
│   ├── getuserdata.php
│   ├── computeresults.php
│   ├── getsizemetrics.php       ← NEW (Lecture 05)
│   └── getcomplexity.php        ← NEW (Lecture 06)
├── frontend/
│   ├── index.html
│   ├── login.html
│   ├── signup.html
│   ├── survey.html
│   ├── postpartum.html
│   ├── metrics_dashboard.html   ← UPDATED (new tabs added)
│   ├── style.css
│   ├── auth.css
│   ├── tracker.js
│   ├── slideshow.js
│   └── review.js
├── database/
│   └── maternal_health_uganda.sql  ← UPDATED (10 new tables)
├── images/
├── Metric(documentation)/
│   ├── lecture 02.md
│   ├── lecture 03(GQM).md
│   ├── lecture 04 (EmpiricalInvestigation).md
│   ├── lecture 05 (SoftwareSize).md        ← NEW
│   ├── lecture 06 (StructuralComplexity).md ← NEW
│   └── MANUAL.md                            ← NEW
└── README(1).md
```
